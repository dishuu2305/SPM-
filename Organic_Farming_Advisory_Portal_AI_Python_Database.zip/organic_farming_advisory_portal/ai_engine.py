"""
Lightweight offline advisory engine.
This is a transparent keyword/rule-based NLP demo, not a trained ML model
and not a substitute for advice from a local agricultural expert.
"""

KNOWLEDGE = {
    "compost": ("Compost improves soil organic matter. Mix dry plant material with green waste "
                "and animal manure where appropriate, keep it moist but not waterlogged, and turn "
                "it periodically. Use mature, well-decomposed compost."),
    "fertilizer": ("For organic nutrient management, consider mature compost, vermicompost, "
                   "green manures and locally approved organic inputs. Choose quantities based "
                   "on soil testing and crop needs; avoid applying fresh manure directly to crops."),
    "pest": ("Start with integrated pest management: monitor the crop, identify the pest correctly, "
             "remove heavily affected plant parts where practical, encourage beneficial insects, "
             "use crop rotation and physical barriers, and seek locally approved biological controls."),
    "disease": ("Remove and safely manage infected plant material, avoid overhead irrigation when "
                "it encourages leaf disease, improve spacing and airflow, rotate crops, and confirm "
                "the disease before selecting a treatment."),
    "soil": ("Maintain soil health with organic matter, crop rotation, cover crops, mulching and "
             "reduced soil disturbance where suitable. A soil test helps identify pH and nutrient needs."),
    "water": ("Use water efficiently through mulching, timely irrigation, drip systems where feasible, "
              "rainwater harvesting and checking soil moisture before watering."),
    "certification": ("Organic certification requirements depend on the applicable standard and sales "
                      "channel. In India, explore the NPOP and PGS-India pathways and confirm current "
                      "requirements with an authorized regional agency or official government source."),
    "weed": ("Use preventive weed management such as stale seedbeds, mulching, timely mechanical or "
             "manual weeding, crop rotation and suitable cover crops. Choose methods according to crop "
             "stage and local conditions."),
    "market": ("Explore farmer producer organizations, cooperatives, local organic markets and direct "
               "buyer relationships. Keep production and input records and verify buyer quality requirements."),
    "rotation": ("Rotate crops from different plant families and include legumes or cover crops where "
                 "appropriate. Rotation can help break pest cycles and support soil fertility.")
}

def get_farming_answer(question):
    q = question.lower()
    for keyword, answer in KNOWLEDGE.items():
        if keyword in q or (keyword == "pest" and "insect" in q):
            return answer
    return ("I can help with compost, organic fertilizers, pest and disease management, soil health, "
            "irrigation, crop rotation, certification and market access. Please ask a more specific "
            "question and mention your crop and region for more relevant general guidance.")

def recommend_crops(soil, season, water):
    # Educational demo rules only. Local climate, variety, sowing window and soil tests matter.
    rules = {
        ("Loamy", "Kharif", "High"): (["Rice", "Maize", "Soybean"], "These are illustrative options often considered in warm, rainy-season conditions."),
        ("Loamy", "Rabi", "Medium"): (["Wheat", "Chickpea", "Mustard"], "These are illustrative cool-season options; local sowing dates and varieties matter."),
        ("Black", "Kharif", "Medium"): (["Cotton", "Soybean", "Pigeon pea"], "Black soils can suit several rainfed crops, depending on drainage and local rainfall."),
        ("Black", "Rabi", "Low"): (["Chickpea", "Safflower"], "These options may be considered in some moisture-limited black-soil regions."),
        ("Sandy", "Kharif", "Low"): (["Pearl millet", "Groundnut"], "Drought-tolerant options may be more suitable in low-water sandy areas."),
        ("Sandy", "Rabi", "Medium"): (["Mustard", "Chickpea"], "These are illustrative options; nutrient and irrigation planning is important."),
        ("Clay", "Kharif", "High"): (["Rice", "Jute"], "Water-tolerant crops may be considered where drainage and local climate are suitable."),
        ("Clay", "Rabi", "Medium"): (["Wheat", "Lentil"], "Check field drainage and local recommendations before selection.")
    }
    crops, reason = rules.get((soil, season, water),
        (["Millets", "Pulses", "Seasonal vegetables"], "General options only. Obtain a local recommendation using soil test results and district-level crop guidance."))
    return {"crops": crops, "reason": reason}
