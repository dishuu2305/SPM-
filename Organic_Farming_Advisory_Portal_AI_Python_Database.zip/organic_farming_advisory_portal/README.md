# Organic Farming Advisory Portal

A student-project web application for an **Organic Farming Advisory Portal**. It uses:
- Python + Flask for the backend
- SQLite for persistent data storage
- A lightweight offline keyword/rule-based advisory engine
- A rule-based crop suggestion demo

## Features
1. Farmer registration, login and logout
2. Dashboard with saved recommendation count and recent recommendations
3. Crop recommendation form (soil, season and water availability)
4. Organic farming assistant for compost, fertilizers, pests, diseases, soil, irrigation, certification, weeds and markets
5. Organic certification information page
6. Database tables for users, recommendations and chatbot history
7. JSON endpoint at `POST /api/chat` for assistant integration

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this ZIP folder.
3. Open Command Prompt in the extracted `organic_farming_advisory_portal` folder.
4. Create and activate a virtual environment:

   ```bat
   python -m venv venv
   venv\Scripts\activate
   ```

5. Install dependencies:

   ```bat
   pip install -r requirements.txt
   ```

6. Start the website:

   ```bat
   python app.py
   ```

7. Open `http://127.0.0.1:5000` in your browser and register a new account.

The SQLite database `organic_farming.db` is created automatically on first run.

## Important notes
- The assistant is an offline, rule-based NLP demonstration. It is not a trained machine-learning model or a generative AI model.
- Crop suggestions are illustrative educational outputs, not agronomic prescriptions. Confirm crop choices with local agricultural extension officers and soil-test results.
- Certification rules can change. Verify current requirements with the relevant official certification body.
- Before deployment, replace `SECRET_KEY`, turn off Flask debug mode, add CSRF protection, input validation, rate limiting and HTTPS.
- This is a standalone starter project. It does not modify or merge with your original website because the original website ZIP was not attached in the chat.
