from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from database import init_db, get_db
from ai_engine import get_farming_answer, recommend_crops

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key-before-deployment"
init_db()

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter all details. Password must contain at least 6 characters.", "danger")
            return render_template("register.html")
        db = get_db()
        try:
            db.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                       (name, email, generate_password_hash(password)))
            db.commit()
        except Exception:
            flash("This email may already be registered.", "danger")
            return render_template("register.html")
        flash("Account created. Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    count = db.execute("SELECT COUNT(*) FROM recommendations WHERE user_id=?", (session["user_id"],)).fetchone()[0]
    recent = db.execute("SELECT * FROM recommendations WHERE user_id=? ORDER BY created_at DESC LIMIT 3",
                        (session["user_id"],)).fetchall()
    return render_template("dashboard.html", count=count, recent=recent)

@app.route("/crop-recommendation", methods=["GET", "POST"])
@login_required
def crop_recommendation():
    result = None
    if request.method == "POST":
        soil = request.form.get("soil", "")
        season = request.form.get("season", "")
        water = request.form.get("water", "")
        region = request.form.get("region", "").strip()
        result = recommend_crops(soil, season, water)
        db = get_db()
        db.execute("""INSERT INTO recommendations(user_id,soil,season,water,region,crops,reason)
                      VALUES(?,?,?,?,?,?,?)""",
                   (session["user_id"], soil, season, water, region,
                    ", ".join(result["crops"]), result["reason"]))
        db.commit()
    return render_template("crop.html", result=result)

@app.route("/assistant", methods=["GET", "POST"])
@login_required
def assistant():
    answer = None
    question = ""
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        if question:
            answer = get_farming_answer(question)
            db = get_db()
            db.execute("INSERT INTO chat_history(user_id,question,answer) VALUES(?,?,?)",
                       (session["user_id"], question, answer))
            db.commit()
    history = get_db().execute(
        "SELECT question,answer,created_at FROM chat_history WHERE user_id=? ORDER BY id DESC LIMIT 8",
        (session["user_id"],)).fetchall()
    return render_template("assistant.html", answer=answer, question=question, history=history)

@app.route("/certification")
def certification():
    return render_template("certification.html")

@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    if not question:
        return jsonify({"error": "Question is required"}), 400
    answer = get_farming_answer(question)
    db = get_db()
    db.execute("INSERT INTO chat_history(user_id,question,answer) VALUES(?,?,?)",
               (session["user_id"], question, answer))
    db.commit()
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
